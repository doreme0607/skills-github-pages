document.getElement by ID("sus")innertext="mesage set";

  
        
          
